public class weekTemperatures {
    public static void main(String[] args) {
        int [] temperatures={10,15,25,65,85,25,63,45,12,45};
        int max=temperatures[0];
        int min=temperatures[0];
        for (int a=0; a< temperatures.length;a++){
            if (max<temperatures[a]){
                max =temperatures[a];
            }
            if (min > temperatures[a]) {
                min=temperatures[a];
            }
        }
        System.out.println("max temp is "+max+" ");
        System.out.print("min temp is "+min+" ");
    }
}
