public class Q7 {
    public static void main(String[] args) {
        int sum=-1;
        int sum1=0;
        for (int a=0; a<10;a++){
            sum=sum1-sum;
            sum1 = sum+sum1;
            System.out.print(sum1+"  ");
        }

    }
}
