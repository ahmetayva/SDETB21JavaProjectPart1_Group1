public class arraysOddEven {
    public static void main(String[] args) {
        int [][] arrays=new int[][]{
                {10,5,6,32,85,15},
                {5,85,65,6,9,15},
                {78,85,96,35,26},
        };
        int sum=0;
        for (int i=0;i< arrays.length;i++){
            for (int a=0;a<arrays[i].length;a++){
                if (arrays[i][a]%2==0){
                    sum=sum+arrays[i][a];
                }
            }
        }
        System.out.println("sum even is "+sum);
    }
}
