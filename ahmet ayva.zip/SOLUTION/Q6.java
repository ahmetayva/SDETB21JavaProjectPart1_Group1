import java.util.Scanner;

public class asalSayi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("please enter number: ");
        int sayi = scanner.nextInt();
        boolean asal = true;

        if (sayi <= 1) {
            asal = false;
        } else {
            for (int i = 2; i <= sayi / 2; i++) {
                if (sayi % i == 0) {
                    asal = false;
                    break;
                }
            }
        }

        if (asal) {
            System.out.println(sayi + " is a prime number.");
        } else {
            System.out.println(sayi + " is not a prime number.");
        }
    }
}


