public class arraysSum {
    public static void main(String[] args) {
        int [] arrays={10,15,25,65,32,25,85,96,36};
        int sum=0;
        for (int i=0; i<arrays.length;i++){
            sum=sum+arrays[i];
        }
        System.out.println("sum is "+ sum);
    }
}
